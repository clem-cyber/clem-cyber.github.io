/**
 * \file      SpaceInvaders.cxx
 *
 * \author    Marc Laporte
 *
 * \date      28/10/2015
 *
 * \note      Last modification 19/11/2015
 *
 * \brief     Essais pour l'implémentation de space invaders
 *
 */

#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
#include <utility>    // max()

using namespace std;

namespace
{
    typedef vector <string> CVString;
    
    const char KEmpty               = ' ';
    const char KInsideInvader       = 'W';
    const char KInsideMe            = 'A';
    const char KTorpedo             = '|';  // For me
    const char KMissile             = 'T';  // For Invaders
    const char KRight               = '6';
    const char KLeft                = '4';
    const char KShoot               = '5';

    const unsigned KInvadersSize      = 4;
    const unsigned KInvadersMiddle    = KInvadersSize / 2;
    const unsigned KMySize            = 1;
    const unsigned KMyMiddle          = KMySize / 2;
    const unsigned KSizeLine          = 10;
    const unsigned KSizeSpace         = 10;
    const unsigned KBegInvader        = 0;
    const unsigned KBegMe             = KSizeLine / 2;
    
    const unsigned KRatioMeInvaders = 4;
    
    string KEmptyLine (KSizeLine, KEmpty);
    
    const string KInvadersForm (KInvadersSize, KInsideInvader);
    const string KMyForm       (KMySize,       KInsideMe);
    
    const string KReset   ("0");
    const string KBlack   ("30");
    const string KRed     ("31");
    const string KGreen   ("32");
    const string KMyColor (KGreen);
    const string KYellow  ("33");
    const string KInvadersColor (KYellow);
    const string KBlue    ("34");
    const string KMAgenta ("35");
    const string KCyan    ("36");
        
    void Colour (const string & Coul)
    {
        cout << "\033[" << Coul <<"m";
        
    }// Colour()

    void ClearScreen ()
    {
        cout << "\033[H\033[2J";
        
    } //ClearScreen()
    
/*    */
    void GotoXY (unsigned X, unsigned Y)
    {
        cout << "\033[" << Y << ';' << X << "H";
        
    } // gotoxy()                 
/*    */
             
    void DownShift (CVString & Space, unsigned CurrentLine)
    {
        for (unsigned i (CurrentLine); i > 0; --i)
            Space [i] = Space [i - 1];
        Space [0] = KEmptyLine;
            
    } // DownShift()
    
    bool IsDead (const CVString & Space, unsigned Line, unsigned Column,
                 char Who)
    {
        return Space [Line][Column] != Who &&
               (Space [Line][Column] == KInsideInvader ||
                Space [Line][Column] == KInsideMe);
               
    } // IsDead()
    
    bool Shoot (CVString & Space, unsigned Line, unsigned Middle,
                char Projectile, char Who)
    {
        if (IsDead (Space, Line, Middle, Who))
        {
            Space [Line] = KEmptyLine;
            return true;
        }
        Space [Line][Middle] = 
                KEmpty == Space [Line][Middle] ? Projectile : KEmpty;
        return false;
        
    } // Shoot()
            
    bool ManageInvader (int & Increment, unsigned & CurrentLine,   
                        unsigned & Beg, bool & ToShoot, 
                        bool & Win, CVString & Space)
    {   
/*    */
        if ((Increment > 0 &&
               (Beg + KInvadersSize == KSizeLine ||
                Space [CurrentLine][Beg + KInvadersSize] != KEmpty)) 
           ||
            (Increment < 0 &&
               (Beg  == 0 ||
                Space [CurrentLine][Beg - 1] != KEmpty)))
        {
            ++CurrentLine;
            for (unsigned j (Beg); j < Beg + KInvadersSize; ++j)
            {
                if (KTorpedo == Space [CurrentLine][j])
                {
                    Win = true;
                    Space [CurrentLine] = KEmptyLine;
                    return false;
                }
            }
                    
            Increment *= -1;
            DownShift (Space, CurrentLine);
            if (Space.size () - 1 <= CurrentLine)
                return true;
        }
        else
        {
            string ToShift (Space [CurrentLine].
                                  substr (Increment > 0 ? 0 : 1, 
                                          KSizeLine - 1));
            Space [CurrentLine] = (Increment > 0) ? ' ' + ToShift 
                                  : ToShift + ' ';
        }
        Beg +=Increment;
        ToShoot = ! ToShoot;
 /*    */
        if (ToShoot)
        {
            return Shoot (Space, CurrentLine + 1, 
                          Beg + KInvadersMiddle, KMissile, KInsideInvader);
        }
 /*    */
        
        return false;
        
    } // ManageInvaders()

    void Remove (CVString & Space, unsigned Line, unsigned Column)
    {
        char Form = Space [Line][Column];
        for (unsigned j (Column); j < KSizeLine && 
                                Space [Line][j] == Form; ++j)
            Space [Line][j] = KEmpty;
        for (unsigned j (Column); j-- > 0 && 
                                Space [Line][j] == Form; )
            Space [Line][j] = KEmpty;
        
    } // Remove()
    
    void RecomputeSpace (CVString & Space, bool & Win, bool & Lost)
    {
/*    */
        for (unsigned i (0); i < KSizeSpace; ++i)
        {
            for (unsigned j (0); j < KSizeLine; ++j)
            {
                if (KTorpedo == Space [i][j])
                {
                    if (i != 0)
                    {
                        if (KInsideInvader == Space [i - 1][j])
                        {
                            Remove (Space, i - 1, j);
                            Win = true;
                        }
                        else if (KMissile == Space [i - 1][j])
                        {
                            Space [i - 1][j] = KEmpty;                           
                        }
                        else
                        {
                            Space [i - 1][j] = KTorpedo;
                        }
                        Space [i][j]     = KEmpty;
                    }
                    else
                    {
                        Space [i][j] = KEmpty;
                    }
                }
                else if (KMissile == Space [i][j])
                {
/* le probleme est de ne pas faire avancer le missile de plus d'un */
                    if (i != KSizeSpace - 1)
                    {
                        if (KInsideMe == Space [i + 1][j])
                        {
                            Remove (Space, i + 1, j);
                            Lost = true;
                            Space [i][j]     = KEmpty;
                        }
                        else if (KTorpedo == Space [i + 1][j])
                        {
                            Space [i + 1][j] = KEmpty;                           
                            Space [i][j]     = KEmpty;
                        }
                        else
                        {
                            if (i > 0 && KMissile == Space[i - 1][j])
                            {
                                Space [i - 1][j] = KEmpty;
                            }
                            else
                            {
                                Space [i + 1][j] = KMissile;
                            }
                        }
                    }
                    else if (KMissile == Space [i - 1][j])
                    {
                        Space [i - 1][j] = KEmpty;
                    }
                    else
                    {
                        Space [i][j] = KEmpty;
                    }
                }
            }
        }
/*    */
        
    } // RecomputeSpace()
    
    void DisplaySpace (const CVString & Space)
    {
        ClearScreen ();
        for (string Line : Space)
        {
            cout << Line.size ();
            for (unsigned Col (0); Col < Line.size (); ++Col)
            {
                switch (Line [Col])
                {
                  case KInsideMe :
                  case KTorpedo  : 
                    Colour (KInvadersColor);
                    break;
                  case KInsideInvader :
                  case KMissile       : 
                    Colour (KMyColor);
                    break;
                }
                cout << Line [Col];

                Colour (KReset);
            }
            cout << Line.size ();
            cout << endl;
        }
    
    } // DisplaySpace()
    
    bool ManageMe (CVString & Space, unsigned & Pos, bool & Lost)
    {
        char C;
        cin >> C;
/*    */
        unsigned Line = Space.size () - 1;
        string NewLastLine = Space [Line];
        switch (C)
        {
          case KLeft    :
            if (Pos > 0)
            {
                --Pos;
                if (IsDead (Space, Line, Pos, KInsideMe))
                {
                    NewLastLine = KEmptyLine;
                    Lost = true;
                }
                else
                {
                    NewLastLine = Space [Line].substr (0, Pos) +
                                  Space [Line].substr (Pos + 1) + ' ';
                }
            }
            break;
          case KRight   :
            if (Pos < KSizeLine - 1)
            {            
                ++Pos;
                if (IsDead (Space, Line, Pos, KInsideMe))
                {
                    NewLastLine = KEmptyLine;
                    Lost = true;
                }
                else
                {
                    NewLastLine = Space [Line].substr (0, Pos - 1) + ' ' +
                                  Space [Line].substr (Pos - 1, 
                                                        KSizeLine - Pos);
                }
            }
            break;
          case KShoot :
            return Shoot (Space, Line - 1, Pos, KTorpedo, KInsideMe);
        }
        Space [Line] = NewLastLine;
        
/*    */
        return false;
        
    } // ManageMe()
    
    void InitSpace (CVstring & Space, unsigned Size)
    {
        Space.resize (Size);
        for (string & Line : Space)
        {   
            Line = KEmptyLine;
        }
        Space [0] = KEmptyLine.substr (0, KBegInvader) +
                    KInvadersForm +
                    KEmptyLine.substr (0, 
                                       KSizeLine - KBegInvader 
                                                 - KInvadersSize); 
        Space [Space.size () - 1] = KEmptyLine.substr (0, KBegMe) + KMyForm +
                                    KEmptyLine.substr 
                                            (0, KSizeLine - KBegMe - KMySize);         
    } // InitSpace()
    
    void SpaceInvaders (void)
    {
        CVString Space;

        InitSpace (Space, KSizeSpace);
        int Direction = 1;
        unsigned CurrentLine (0);
        unsigned PosInvader (KBegInvader);
        unsigned PosMe      (KBegMe);
        
        bool IWin           = false;
        bool ILoose         = false;
        bool InvadersShoots = false;
        DisplaySpace (Space);
        GotoXY (10, 20);
        for (;;)
        {
            for (unsigned i (max (2u, KRatioMeInvaders)); i-- > 0; )
            {
                if (!ManageMe (Space, PosMe, ILoose) && ! ILoose)
                {
                    RecomputeSpace (Space, IWin, ILoose);
                }
                DisplaySpace (Space);
                if (ILoose || IWin) break;
            }
            if (ILoose || IWin) break;
            ILoose = ManageInvader (Direction, CurrentLine, PosInvader, 
                                    InvadersShoots, IWin, Space);
            if (! IWin && ! ILoose)
                RecomputeSpace (Space, IWin, ILoose);
            DisplaySpace (Space);
            if (ILoose || IWin) break;
        }
        if (IWin)
        {
            cout << "J'ai gagné" << endl;
        }
        else
        {
            cout << "J'ai perdu" << endl;
        }
        
    } // SpaceInvaders()
    
} // namespace

int main ()
{
    SpaceInvaders ();
    
    return 0;
    
} // main()
